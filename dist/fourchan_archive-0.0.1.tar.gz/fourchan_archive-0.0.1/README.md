# 4Chan Archive

Command line utility for making archives of 4chan threads.
