
class ErrorReceiving:
    Message = "Failed to receive data."

class ErrorInvalidURL:
    Message = "Can't handle this URL."
